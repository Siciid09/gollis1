import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/firebase-admin";

// GET ALL MEASUREMENTS
export async function GET() {
  try {
    const snapshot = await db.collection("measurements").orderBy("measurementDate", "desc").get();
    const measurements = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    return NextResponse.json({ success: true, data: measurements });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// CREATE NEW MEASUREMENT
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    
    const newRecord = {
      ...body,
      createdAt: new Date().toISOString()
    };

    const docRef = await db.collection("measurements").add(newRecord);
    
    return NextResponse.json({ 
      success: true, 
      data: { id: docRef.id, ...newRecord } 
    }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// UPDATE MEASUREMENT (Using ID in body)
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...updateData } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "Missing ID" }, { status: 400 });
    }

    await db.collection("measurements").doc(id).update({
      ...updateData,
      updatedAt: new Date().toISOString()
    });
    
    return NextResponse.json({ success: true, message: "Measurement updated successfully" });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// DELETE MEASUREMENT (Using ID from URL search params)
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ success: false, error: "Missing ID" }, { status: 400 });
    }

    await db.collection("measurements").doc(id).delete();
    
    return NextResponse.json({ success: true, message: "Measurement deleted" });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}